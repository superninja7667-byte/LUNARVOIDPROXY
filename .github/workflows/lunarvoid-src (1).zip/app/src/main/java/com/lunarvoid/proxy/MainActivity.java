package com.lunarvoid.proxy;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

import org.json.JSONObject;

import engine.Engine;

public class MainActivity extends Activity {
    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.parseColor("#020712"));
        getWindow().setNavigationBarColor(Color.parseColor("#020712"));

        Engine.call("{\"action\":\"init\",\"dir\":" + JSONObject.quote(getFilesDir().getAbsolutePath()) + "}");

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#020712"));
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        web.addJavascriptInterface(new Bridge(), "LunarVoidNative");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.removeJavascriptInterface("LunarVoidNative");
        }
        super.onDestroy();
    }

    /** Functions the app screen (index.html) calls as window.LunarVoidNative.*. */
    private class Bridge {
        /** Every game request from the page: sign-in, start/stop, uploads, status. */
        @JavascriptInterface
        public String gameCall(String json) {
            String action = "";
            try {
                action = new JSONObject(json).optString("action");
            } catch (Exception ignored) {
            }
            String result = Engine.call(json);
            try {
                String state = new JSONObject(result).optString("state");
                if (action.equals("start") && (state.equals("starting") || state.equals("listening") || state.equals("connected"))) {
                    ProxyService.begin(MainActivity.this);
                } else if ((action.equals("stop") || action.equals("signout") || action.equals("removeAccount")) && state.equals("stopped")) {
                    ProxyService.end(MainActivity.this);
                }
            } catch (Exception ignored) {
            }
            return result;
        }

        /** Opens the Microsoft sign-in page in the browser. */
        @JavascriptInterface
        public void openGameSignIn() {
            String link = "";
            try {
                link = new JSONObject(Engine.call("{\"action\":\"status\"}")).optString("authLink");
            } catch (Exception ignored) {
            }
            final String url = link.isEmpty() ? "https://www.microsoft.com/link" : link;
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Could not open the sign-in page.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        // The old "forwarding without the menu" relay is not part of this build.
        // These answer politely so the page keeps working.
        @JavascriptInterface
        public String startProxy(String ip, String port, boolean lan) {
            return "{\"state\":\"stopped\",\"error\":\"Forwarding without the menu is not in this build yet. Keep the in-game menu switch on.\"}";
        }

        @JavascriptInterface
        public String stopProxy() {
            return "{\"state\":\"stopped\"}";
        }

        @JavascriptInterface
        public String status() {
            return "{\"state\":\"stopped\"}";
        }

        @JavascriptInterface
        public void openUrl(final String url) {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Could not open the link.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void openMinecraft() {
            runOnUiThread(() -> {
                Intent i = getPackageManager().getLaunchIntentForPackage("com.mojang.minecraftpe");
                if (i == null) {
                    Toast.makeText(MainActivity.this, "Minecraft is not installed.", Toast.LENGTH_SHORT).show();
                } else {
                    startActivity(i);
                }
            });
        }
    }
}
