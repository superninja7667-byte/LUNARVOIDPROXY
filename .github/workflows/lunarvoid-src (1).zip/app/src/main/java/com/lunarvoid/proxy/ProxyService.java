package com.lunarvoid.proxy;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import engine.Engine;

/** Keeps the proxy alive in the background while you play Minecraft. */
public class ProxyService extends Service {
    private static final String CHANNEL = "lunarvoid_proxy";
    private static final String ACTION_STOP = "com.lunarvoid.proxy.STOP";
    private static final int NOTIF_ID = 1;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable batteryTick = new Runnable() {
        @Override
        public void run() {
            BatteryManager bm = (BatteryManager) getSystemService(BATTERY_SERVICE);
            if (bm != null) {
                int level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
                String status = Engine.call("{\"action\":\"battery\",\"level\":" + level + "}");
                if (status.contains("\"state\":\"stopped\"")) {
                    stopSelf(); // the proxy ended (stopped or failed to start)
                    return;
                }
            }
            handler.postDelayed(this, 5000);
        }
    };

    public static void begin(Context ctx) {
        ctx.startForegroundService(new Intent(ctx, ProxyService.class));
    }

    public static void end(Context ctx) {
        ctx.stopService(new Intent(ctx, ProxyService.class));
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            Engine.call("{\"action\":\"stop\"}");
            stopSelf();
            return START_NOT_STICKY;
        }

        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "LUNARVOID proxy", NotificationManager.IMPORTANCE_LOW));

        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, ProxyService.class).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE);

        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("LUNARVOID proxy is running")
                .setContentText("In Minecraft, join 127.0.0.1 port 19132")
                .setContentIntent(open)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, R.drawable.ic_notification), "Stop", stop).build())
                .build();

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIF_ID, n);
        }

        handler.removeCallbacks(batteryTick);
        handler.post(batteryTick);
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(batteryTick);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
