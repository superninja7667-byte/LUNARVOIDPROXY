module lunarvoid/engine

go 1.25

require github.com/sandertv/gophertunnel v1.62.0
