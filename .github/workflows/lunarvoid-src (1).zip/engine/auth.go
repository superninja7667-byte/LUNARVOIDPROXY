package engine

import (
	"encoding/json"
	"os"
	"path/filepath"
	"regexp"
	"strings"

	"github.com/sandertv/gophertunnel/minecraft/auth"
	"golang.org/x/oauth2"
)

var (
	linkRe = regexp.MustCompile(`https?://[^\s]+`)
	codeRe = regexp.MustCompile(`(?i)code\s+([A-Z0-9]{6,12})`)
	otcRe  = regexp.MustCompile(`otc=([A-Za-z0-9]+)`)
)

// captureWriter receives the "go to this page and enter this code" text that
// the sign-in library prints, so the app can show it.
type captureWriter struct {
	s   *engineState
	gen int
}

func (w *captureWriter) Write(p []byte) (int, error) {
	text := strings.TrimSpace(string(p))
	w.s.mu.Lock()
	defer w.s.mu.Unlock()
	if w.s.authGen != w.gen {
		return len(p), nil
	}
	w.s.auth.Message = text
	if m := linkRe.FindString(text); m != "" {
		w.s.auth.Link = strings.TrimRight(m, ".,")
	}
	if m := codeRe.FindStringSubmatch(text); m != nil {
		w.s.auth.Code = m[1]
	} else if m := otcRe.FindStringSubmatch(text); m != nil {
		w.s.auth.Code = m[1]
	}
	return len(p), nil
}

func (s *engineState) startSignIn() {
	s.mu.Lock()
	if s.auth.State == "pending" {
		s.mu.Unlock()
		return
	}
	s.authGen++
	gen := s.authGen
	s.auth = authInfo{State: "pending"}
	s.mu.Unlock()

	go func() {
		tok, err := auth.RequestLiveTokenWriter(&captureWriter{s: s, gen: gen})
		s.mu.Lock()
		defer s.mu.Unlock()
		if s.authGen != gen {
			return // cancelled
		}
		if err != nil {
			s.auth = authInfo{State: "error", Err: err.Error()}
			return
		}
		s.tokenSource = auth.RefreshTokenSource(tok)
		s.writeToken(tok)
		s.auth = authInfo{State: "done"}
	}()
}

func (s *engineState) cancelSignIn() {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.authGen++
	s.auth = authInfo{State: "idle"}
}

func (s *engineState) signOut() {
	s.stop()
	s.mu.Lock()
	defer s.mu.Unlock()
	s.tokenSource = nil
	s.accountName = ""
	s.auth = authInfo{State: "idle"}
	if s.dir != "" {
		_ = os.Remove(filepath.Join(s.dir, "token.json"))
	}
	s.persist()
}

// writeToken saves the sign-in token. The caller must hold s.mu.
func (s *engineState) writeToken(tok *oauth2.Token) {
	if s.dir == "" || tok == nil {
		return
	}
	if b, err := json.Marshal(tok); err == nil {
		_ = os.WriteFile(filepath.Join(s.dir, "token.json"), b, 0o600)
	}
}
