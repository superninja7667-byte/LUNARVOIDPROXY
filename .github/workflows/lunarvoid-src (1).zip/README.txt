LUNARVOID PROXY - source (test build 2)

engine/   Go proxy engine (built into an .aar by the GitHub workflow)
  pack/   the in-game menu resource pack (JSON UI)
app/      Android app: your LunarVoid app screen (assets/index.html) + background service
The workflow file is .github/workflows/build.yml (you add it on GitHub).
