LUNARVOID PROXY - source (build 4: old engine)

app/                 Android app
  src/main/jniLibs/  liblunarvoid50.so = your OLD engine, unchanged (sign-in, joining, menu, replay)
  src/main/assets/   index.html = your v4 app screen
  lunarvoid.jks      fixed signing key: every build installs over the last one.
                     Keep your repository PRIVATE.
archive/new-engine/  the engine I wrote earlier (new in-game menu). Not built right now; kept for later.
The workflow file is .github/workflows/build.yml (you edit it once on GitHub).
