LUNARVOID PROXY - source (test build 3)

engine/   Go proxy engine (built into an .aar by the GitHub workflow)
  pack/   the in-game menu resource pack (JSON UI)
app/      Android app: your LunarVoid app screen (assets/index.html) + background service
  lunarvoid.jks   fixed signing key: every build is signed the same, so new builds
                  install over the old one. Keep your repository PRIVATE.
The workflow file is .github/workflows/build.yml (you add it on GitHub).
