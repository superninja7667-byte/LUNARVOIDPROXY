// Package engine is the LUNARVOID proxy core. The Android app talks to it
// through one function, Call, which takes and returns JSON.
package engine

import (
	"encoding/json"
	"os"
	"path/filepath"
	"sync"

	"github.com/sandertv/gophertunnel/minecraft/auth"
	"golang.org/x/oauth2"
)

type settings struct {
	Coordinates bool `json:"coordinates"`
	Battery     bool `json:"battery"`
	Ping        bool `json:"ping"`
	EmoteMenu   bool `json:"emoteMenu"`
}

func (st settings) get(key string) bool {
	switch key {
	case "coordinates":
		return st.Coordinates
	case "battery":
		return st.Battery
	case "ping":
		return st.Ping
	case "emote":
		return st.EmoteMenu
	}
	return false
}

func (st *settings) set(key string, v bool) {
	switch key {
	case "coordinates":
		st.Coordinates = v
	case "battery":
		st.Battery = v
	case "ping":
		st.Ping = v
	case "emote":
		st.EmoteMenu = v
	}
}

type authInfo struct {
	State   string // idle, pending, done, error
	Message string
	Link    string
	Code    string
	Err     string
}

type engineState struct {
	mu          sync.Mutex
	dir         string
	state       string // stopped, starting, running, error
	errText     string
	listenPort  int
	settings    settings
	battery     int
	accountName string
	auth        authInfo
	tokenSource oauth2.TokenSource
	gen         int
	run         *runner
}

var eng = &engineState{
	state:      "stopped",
	listenPort: 19132,
	battery:    -1,
	settings:   settings{Coordinates: true, EmoteMenu: true},
	auth:       authInfo{State: "idle"},
}

type request struct {
	Action string `json:"action"`
	Dir    string `json:"dir"`
	Host   string `json:"host"`
	Port   int    `json:"port"`
	Level  int    `json:"level"`
	Key    string `json:"key"`
	Value  bool   `json:"value"`
}

// Call runs one JSON request and returns the current status as JSON.
func Call(requestJSON string) string {
	var r request
	if err := json.Unmarshal([]byte(requestJSON), &r); err != nil {
		return `{"error":"bad request"}`
	}
	switch r.Action {
	case "init":
		eng.init(r.Dir)
	case "signin":
		eng.startSignIn()
	case "signout":
		eng.signOut()
	case "start":
		eng.start(r.Host, r.Port)
	case "stop":
		eng.stop()
	case "battery":
		eng.mu.Lock()
		eng.battery = r.Level
		eng.mu.Unlock()
	case "setting":
		eng.mu.Lock()
		eng.settings.set(r.Key, r.Value)
		eng.persist()
		eng.mu.Unlock()
	}
	return eng.statusJSON()
}

type persisted struct {
	Settings    settings `json:"settings"`
	AccountName string   `json:"accountName"`
}

func (s *engineState) init(dir string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if dir == "" || s.dir != "" {
		return
	}
	s.dir = dir
	_ = os.MkdirAll(dir, 0o755)
	if b, err := os.ReadFile(filepath.Join(dir, "state.json")); err == nil {
		var p persisted
		if json.Unmarshal(b, &p) == nil {
			s.settings = p.Settings
			s.accountName = p.AccountName
		}
	}
	if b, err := os.ReadFile(filepath.Join(dir, "token.json")); err == nil {
		var t oauth2.Token
		if json.Unmarshal(b, &t) == nil && t.RefreshToken != "" {
			s.tokenSource = auth.RefreshTokenSource(&t)
			s.auth = authInfo{State: "done"}
		}
	}
}

// persist writes settings to disk. The caller must hold s.mu.
func (s *engineState) persist() {
	if s.dir == "" {
		return
	}
	b, err := json.Marshal(persisted{Settings: s.settings, AccountName: s.accountName})
	if err == nil {
		_ = os.WriteFile(filepath.Join(s.dir, "state.json"), b, 0o600)
	}
}

func (s *engineState) snapshot() settings {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.settings
}

func (s *engineState) hudState() (settings, int) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.settings, s.battery
}

func (s *engineState) toggle(key string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.settings.set(key, !s.settings.get(key))
	s.persist()
}

func (s *engineState) setAccountName(name string) {
	if name == "" {
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.accountName != name {
		s.accountName = name
		s.persist()
	}
}

func (s *engineState) statusJSON() string {
	s.mu.Lock()
	defer s.mu.Unlock()
	players := 0
	if s.run != nil {
		players = s.run.count()
	}
	m := map[string]any{
		"state":       s.state,
		"error":       s.errText,
		"address":     "127.0.0.1",
		"port":        s.listenPort,
		"signedIn":    s.tokenSource != nil,
		"authState":   s.auth.State,
		"authMessage": s.auth.Message,
		"authLink":    s.auth.Link,
		"authCode":    s.auth.Code,
		"authError":   s.auth.Err,
		"accountName": s.accountName,
		"settings":    s.settings,
		"battery":     s.battery,
		"players":     players,
	}
	b, _ := json.Marshal(m)
	return string(b)
}
