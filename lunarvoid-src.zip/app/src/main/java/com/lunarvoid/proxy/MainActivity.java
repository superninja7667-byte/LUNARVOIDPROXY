package com.lunarvoid.proxy;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

import org.json.JSONObject;

import engine.Engine;

public class MainActivity extends Activity {
    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.parseColor("#020712"));
        getWindow().setNavigationBarColor(Color.parseColor("#020712"));

        Engine.call("{\"action\":\"init\",\"dir\":" + JSONObject.quote(getFilesDir().getAbsolutePath()) + "}");

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#020712"));
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        web.addJavascriptInterface(new Bridge(), "LV");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.removeJavascriptInterface("LV");
        }
        super.onDestroy();
    }

    /** Functions the app screen (index.html) can call as window.LV.*. */
    private class Bridge {
        @JavascriptInterface
        public String call(String json) {
            String action = "";
            try {
                action = new JSONObject(json).optString("action");
            } catch (Exception ignored) {
            }
            String result = Engine.call(json);
            try {
                String state = new JSONObject(result).optString("state");
                if (action.equals("start") && (state.equals("starting") || state.equals("running"))) {
                    ProxyService.begin(MainActivity.this);
                } else if (action.equals("stop") || action.equals("signout")) {
                    ProxyService.end(MainActivity.this);
                }
            } catch (Exception ignored) {
            }
            return result;
        }

        @JavascriptInterface
        public void openUrl(final String url) {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Could not open the link.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void openMinecraft() {
            runOnUiThread(() -> {
                Intent i = getPackageManager().getLaunchIntentForPackage("com.mojang.minecraftpe");
                if (i == null) {
                    Toast.makeText(MainActivity.this, "Minecraft is not installed.", Toast.LENGTH_SHORT).show();
                } else {
                    startActivity(i);
                }
            });
        }
    }
}
