LUNARVOID PROXY - source (test build 1)

engine/   Go proxy engine (built into an .aar by the GitHub workflow)
  pack/   the in-game menu resource pack (JSON UI)
app/      Android app: WebView screen + background service
The workflow file is .github/workflows/build.yml (you add it on GitHub).
