package engine

import (
	"context"
	"net"
	"strings"

	"github.com/sandertv/go-raknet"
	"github.com/sandertv/gophertunnel/minecraft"
)

// phoneRakNet is the normal RakNet network with one change: while connecting,
// it never sends test packets bigger than maxMTU. On some phone and headset
// networks the standard biggest test packet is rejected ("message too long")
// and the connection fails before it even starts. Everything else (pings,
// listening) is inherited unchanged from the normal RakNet network.
type phoneRakNet struct {
	minecraft.RakNet
	maxMTU uint16
}

func (n phoneRakNet) DialContext(ctx context.Context, address string) (net.Conn, error) {
	conn, err := raknet.Dialer{MaxMTU: n.maxMTU}.DialContext(ctx, address)
	if err != nil {
		return nil, err
	}
	return conn, nil
}

// dialWithSmallPackets connects to the server using small test packets first.
// If the size check still fails it retries with smaller sizes before giving up.
func dialWithSmallPackets(ctx context.Context, d minecraft.Dialer, remote string) (*minecraft.Conn, error) {
	var lastErr error
	for _, mtu := range []uint16{1200, 1000, 576} {
		conn, err := d.DialContextNetwork(ctx, phoneRakNet{maxMTU: mtu}, remote)
		if err == nil {
			return conn, nil
		}
		lastErr = err
		if ctx.Err() != nil || !strings.Contains(err.Error(), "discover mtu") {
			break // a different problem (or we ran out of time): do not keep retrying
		}
	}
	return nil, lastErr
}
